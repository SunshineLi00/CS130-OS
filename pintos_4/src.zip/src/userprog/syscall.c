#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
/*the files we add*/
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "pagedir.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "threads/palloc.h"
#include "threads/synch.h"
static void syscall_handler (struct intr_frame *);

void halt (void);
void exit(int status);
pid_t exec (const char *cmd_line);
int wait (pid_t pid);
bool create (const char *file, unsigned initial_size);
bool remove (const char *file);
int open (const char *file);
int filesize (int fd);
int read (int fd, void *buffer, unsigned size);
int write (int fd, const void *buffer, unsigned size);
void seek (int fd, unsigned position);
unsigned tell (int fd);
void close (int fd);

void is_valid_addr (const void *addr);
void is_valid_block (void *buffer, unsigned size);
struct file_d *find_fd (int fd);

struct lock sys_lock;

void
syscall_init (void) 
{
  lock_init (&sys_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  int *syscall_value = (int *)f->esp;
  is_valid_addr (syscall_value);
  //printf("Survived");
  if (*syscall_value < 0 || *syscall_value > 19)
    exit(-1);
  
  int *sys_1 = (int *)f->esp + 1;
  int *sys_2 = (int *)f->esp + 2;
  int *sys_3 = (int *)f->esp + 3;

  switch(*syscall_value){
     case SYS_HALT:
    {
      halt ();
      break;
    }
    case SYS_EXIT:
    {
      is_valid_block((void *)sys_1,3);
      exit(*sys_1);
      break;
    }
    case SYS_EXEC:
    {
      is_valid_block ((void *)sys_1, 3);
      is_valid_block ((void *)(*sys_1), 0);
      f->eax = exec ((const char*)(*sys_1));
      break;
    }
    case SYS_WAIT:
    {
      is_valid_block ((void *)sys_1, 3);
      //is_valid_block ((void *)(*sys_1), 3);
      f->eax = wait ((pid_t)(*sys_1));
      break;
    }
    case SYS_CREATE:
    {
      is_valid_block ((void *)sys_1, 3);
      is_valid_block ((void *)sys_2, 3);
      is_valid_block ((void *)(*sys_1), (unsigned)(*sys_2));
      f->eax = create ((const char*)(*sys_1),(unsigned)(*sys_2));
      break;
    }
    case SYS_REMOVE:
    {
      is_valid_block((void *)sys_1,3);
      is_valid_block ((void *)(*sys_1), 0);
      f->eax = remove ((const char*)(*sys_1));
      break;
    }
    case SYS_OPEN:
    {
      is_valid_block((void *)sys_1,3);
      is_valid_block ((void *)(*sys_1), 0);
      f->eax = open ((const char *)(*sys_1));
      break;
    }
  case SYS_FILESIZE:
    {
      is_valid_block((void *)sys_1,3);
      f->eax = filesize (*sys_1);
      break;
    }
    case SYS_READ:
    {
      is_valid_block((void *)sys_1,3);
      is_valid_block((void *)sys_2,3);
      is_valid_block((void *)sys_3,3);
      is_valid_block ((void *)(*sys_2), (unsigned)(*sys_3));
      f->eax = read (*sys_1, (void *)(*sys_2), (unsigned)(*sys_3));
      break;
    }

    case SYS_WRITE:
    {
      is_valid_block((void *)sys_1,3);
      is_valid_block((void *)sys_2,3);
      is_valid_block((void *)sys_3,3);
      is_valid_block ((void *)(*sys_2), (unsigned)(*sys_3));
      f->eax = write (*sys_1, (void *)(*sys_2), (unsigned)(*sys_3));

      break;
    }

    case SYS_SEEK:
    {
      is_valid_block((void *)sys_1,3);
      is_valid_block((void *)sys_2,3);
      seek(*sys_1, (unsigned)(*sys_2));
      break;
    }
    case SYS_TELL:
    {
      is_valid_block((void *)sys_1,3);
      f->eax = tell(*sys_1);
      break;
    }
    case SYS_CLOSE:
    {
      is_valid_block((void *)sys_1,3);
      close(*sys_1);
      break;
    }
  }
}

void
is_valid_addr (const void *addr)
{
  if (addr == NULL || addr<=0x08008400 || !is_user_vaddr (addr) || pagedir_get_page (thread_current ()->pagedir, addr) == NULL)
    {
      if (lock_held_by_current_thread (&sys_lock))
        lock_release (&sys_lock);
      exit (-1);
    }
}

void
is_valid_block (void *buffer, unsigned size)
{
  for (unsigned i = 0; i <= size; i++)
    is_valid_addr ((const char *)((const char *)buffer+i));
}

/*System Call: void halt (void)
Terminates Pintos by calling shutdown_power_off()*/
void
halt (void)
{
  //printf("r.ltucgnlsiueu6rjfh8cseyij.eli");
  shutdown_power_off ();
}

void
exit (int status)
{
  thread_current()->exit_inf=status;
  printf ("%s: exit(%d)\n", thread_name(), status);
  thread_exit ();
}

pid_t
exec (const char *cmd_line)
{
  lock_acquire (&sys_lock);
  pid_t pid = (pid_t)process_execute (cmd_line);
  lock_release (&sys_lock);
  return pid;
}

int
wait (pid_t pid)
{
  //printf("Surciced\\\n");
  return process_wait (pid);
}

bool
create (const char *file, unsigned initial_size)
{
  if (file==NULL) return false;
  bool temp;
  lock_acquire (&sys_lock);
  temp =  filesys_create (file, initial_size);
  lock_release (&sys_lock);
  return temp;
}

bool
remove (const char *file)
{
  bool temp;
  lock_acquire (&sys_lock);
  temp =  filesys_remove (file);
  lock_release (&sys_lock);
  return temp;
}

int
open (const char *file)
{
   
  //lock_acquire (&sys_lock);
  struct file_d* file_fd = palloc_get_page(0);
  if (!file_fd)
    return -1;
  if(file==NULL) return -1;
  struct file *open_file=filesys_open(file);

  if (!open_file) {
//    lock_release (&sys_lock);
    
    return -1;
  }
  file_fd ->file = open_file;
  
  struct list* fd_list = &thread_current()->fd_list;
  if (list_empty (fd_list))
    file_fd ->fd = 2;
  else
    file_fd ->fd = list_entry (list_back (fd_list), struct file_d, elem)->fd;
  file_fd ->fd ++;
  list_push_back(fd_list, &file_fd ->elem);
  //lock_release (&sys_lock);
  return file_fd->fd;
}

/*System Call: int filesize (int fd)
Returns the size, in bytes, of the file open as fd.*/

int filesize (int fd){
  struct file_d *file_fd = NULL;
  int size;
  lock_acquire (&sys_lock);
  file_fd = find_fd (fd);
  if (file_fd == NULL) {
    lock_release (&sys_lock);
    return -1;
  }
  size = file_length(file_fd->file);
  lock_release (&sys_lock);
  return size;

}


struct file_d *
find_fd (int fd)
{
  struct file_d *file_fd = (struct file_d *) malloc(sizeof(struct file_d));
  struct list*  fd_list = &(thread_current ()->fd_list);
  struct list_elem *e;
  /* Search file_fd in file_list */
  if (list_empty(fd_list ))
    return NULL;
  for(e = list_begin (fd_list ); e != list_end (fd_list ); e = list_next (e))
    {
      file_fd = list_entry(e, struct file_d, elem);
      if(file_fd->fd == fd)
        return file_fd;
    }
     // printf("survive");
  return NULL;
}
/*System Call: int read (int fd, void *buffer, unsigned size)
Reads size bytes from the file open as fd into buffer. 
Returns the number of bytes actually read (0 at end of file), 
or -1 if the file could not be read (due to a condition other than end of file). 
Fd 0 reads from the keyboard using input_getc().*/

int read (int fd, void *buffer, unsigned size){
  //lock_acquire (&sys_lock);
   
  if(fd == STDIN_FILENO)
    {
      for(unsigned i = 0; i < size; i++)
        *(uint8_t *)(buffer + i) = input_getc ();
     // lock_release (&sys_lock);
      return (int)size;
    }

  struct file_d *file_fd = find_fd (fd);
  if (file_fd == NULL || file_fd->file == NULL)
    {
   //   lock_release (&sys_lock);
      return -1;
    }
  int t = file_read (file_fd->file, buffer, size);
 // lock_release (&sys_lock);
  
  return t;

}

/*System Call: int write (int fd, const void *buffer, unsigned size)
Writes size bytes from buffer to the open file fd. Returns the number of bytes actually written, 
which may be less than size if some bytes could not be written.
Writing past end-of-file would normally extend the file, 
but file growth is not implemented by the basic file system.
The expected behavior is to write as many bytes as possible up to end-of-file and return the actual number written,
or 0 if no bytes could be written at all.*/

int write (int fd, const void *buffer, unsigned size){
   lock_acquire (&sys_lock);

  if(fd == STDOUT_FILENO)
    {
      putbuf (buffer, size);
      lock_release (&sys_lock);
      return size;
    }
  if(fd==NULL) return -1;
  struct file_d *file_fd = find_fd (fd);
  // printf("survive");
  if (file_fd == NULL || file_fd->file == NULL)
    {
      lock_release (&sys_lock);
      return -1;
    }
  int t = file_write (file_fd->file, buffer, size);
  lock_release (&sys_lock);
  //printf("survive");
  return t;

}


/*System Call: void seek (int fd, unsigned position)
Changes the next byte to be read or written in open file fd to position, expressed in bytes from the beginning of the file. */

void seek (int fd, unsigned position){
   lock_acquire (&sys_lock);
  struct file_d *file_fd = find_fd (fd);
  if (file_fd == NULL || file_fd->file == NULL)
    {
      lock_release (&sys_lock);
      return;
    }
  file_seek(file_fd->file, position);
  lock_release (&sys_lock);
}

/*System Call: unsigned tell (int fd)
Returns the position of the next byte to be read or written in open file fd, expressed in bytes from the beginning of the file.*/

unsigned tell (int fd){
lock_acquire (&sys_lock);
  struct file_d *file_fd = find_fd (fd);
  if (file_fd == NULL || file_fd->file == NULL)
    {
      lock_release (&sys_lock);
      return -1;
    }
  unsigned t = file_tell (file_fd->file);
  lock_release (&sys_lock);
  return t;
}


/*System Call: void close (int fd)
Closes file descriptor fd. Exiting or terminating a process implicitly closes all its open file descriptors, as if by calling this function for each one.*/
void close (int fd){
lock_acquire (&sys_lock);
  struct file_d *file_fd = find_fd (fd);
  if (file_fd == NULL || file_fd->file == NULL)
    {
      lock_release (&sys_lock);
      return;
    }
  file_close(file_fd->file);
  list_remove(&file_fd->elem);
  lock_release (&sys_lock);
}